import http from 'node:http';
const port=8787;
http.createServer((req,res)=>{
  if(req.url==='/echo'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({url:req.url,headers:req.headers},null,2));return;}
  const headers={'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'};
  if(req.url==='/deny')headers['X-Frame-Options']='DENY';
  if(req.url==='/ancestors')headers['Content-Security-Policy']="frame-ancestors 'none'";
  if(req.url==='/frame-src')headers['Content-Security-Policy']="frame-src 'none'";
  res.writeHead(200,headers);
  res.end(`<!doctype html><html lang="en"><meta charset="utf-8"><title>Local frame fixture</title><body><h1>Local frame fixture</h1><p>This document rendered. Compare direct and embedded navigation.</p><ul><li><a href="/echo">Echo request headers</a></li><li><a href="/deny">X-Frame-Options denial</a></li><li><a href="/ancestors">CSP frame-ancestors denial</a></li><li><a href="/frame-src">Nested frame-src denial</a></li></ul>${req.url==='/frame-src'?'<iframe src="/echo" title="Blocked nested frame"></iframe>':''}</body></html>`);
}).listen(port,'127.0.0.1',()=>console.log(`Fixtures: http://127.0.0.1:${port} (/, /echo, /deny, /ancestors, /frame-src)`));
