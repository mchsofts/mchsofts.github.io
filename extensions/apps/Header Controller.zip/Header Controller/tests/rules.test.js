import {test} from 'node:test';
import assert from 'node:assert/strict';
import {defaults,validate,compile,httpURL,originsFor} from '../src/rules.js';
const rule=(id='a',value='Lab/1')=>({id,name:'Lab',scope:'http://127.0.0.1:8787',enabled:true,headers:[{name:'User-Agent',value,enabled:true}]});
test('disabled defaults compile to no rules',()=>assert.deepEqual(compile(defaults()),[]));
test('exact origin does not leak to suffixes, other ports, subdomains or query strings',()=>{
 const [r]=compile({enabled:true,rules:[rule()]});const re=new RegExp(r.condition.regexFilter,'i');
 assert.ok(re.test('http://127.0.0.1:8787/echo'));
 for(const url of ['http://127.0.0.1:8788/','https://127.0.0.1:8787/','http://127.0.0.1:8787.evil/','http://example.com/?http://127.0.0.1:8787/'])assert.equal(re.test(url),false);
});
test('priority is explicit and disabled headers and rules are absent',()=>{
 const a=rule(),b=rule('b','Other');a.headers.push({name:'Referer',value:'https://example.com/',enabled:false});
 const result=compile({enabled:true,rules:[a,b,{...rule('c'),enabled:false}]});assert.equal(result.length,2);assert.ok(result[0].priority>result[1].priority);assert.equal(result[0].action.requestHeaders.length,1);
});
test('unsafe URLs, scopes, injection and controlled headers rejected',()=>{
 for(const u of ['javascript:alert(1)','file:///x','https://user:pass@example.com'])assert.throws(()=>httpURL(u));
 for(const scope of ['https://example.com/path','https://example.com/?x'])assert.throws(()=>validate({enabled:true,rules:[{...rule(),scope}]}));
 for(const name of ['Host','Sec-Fetch-Dest','Authorization','bad name'])assert.throws(()=>validate({enabled:true,rules:[{...rule(),headers:[{name,value:'x',enabled:true}]}]}));
 assert.throws(()=>validate({enabled:true,rules:[rule('a','good\r\nInjected: yes')]}));
});
test('all sites only HTTP(S); origin and duplicate header validation',()=>{
 assert.deepEqual(originsFor('*'),['http://*/*','https://*/*']);
 const [r]=compile({enabled:true,rules:[{...rule(),scope:'*'}]});assert.equal(new RegExp(r.condition.regexFilter).test('file:///x'),false);
 assert.throws(()=>validate({enabled:true,rules:[{...rule(),headers:[{name:'Origin',value:'https://a.test/path',enabled:true}]}]}));
 assert.throws(()=>validate({enabled:true,rules:[{...rule(),headers:[...rule().headers,...rule().headers]}]}));
});
