import {test} from 'node:test';
import assert from 'node:assert/strict';
let listener,stored,dynamic=[],rejectDNR=false,rejectStorage=false,granted=true;
globalThis.chrome={
 storage:{local:{get:async()=>({settings:stored}),set:async({settings})=>{if(rejectStorage)throw Error('Storage full');stored=structuredClone(settings);}}},
 declarativeNetRequest:{getDynamicRules:async()=>structuredClone(dynamic),updateDynamicRules:async({addRules})=>{if(rejectDNR)throw Error('Chrome rejected header');dynamic=structuredClone(addRules);}},
 permissions:{contains:async()=>granted},
 action:{setBadgeText:async()=>{},setBadgeBackgroundColor:async()=>{}},
 tabs:{onRemoved:{addListener:()=>{}}},
 runtime:{id:'test',onMessage:{addListener:fn=>listener=fn},onInstalled:{addListener:()=>{}},onStartup:{addListener:()=>{}}}
};
await import('../src/background.js');
const send=m=>new Promise(resolve=>listener(m,{id:'test'},resolve));
const settings={enabled:true,rules:[{id:'a',name:'Test',enabled:true,scope:'https://example.com',headers:[{name:'User-Agent',value:'Lab/1',enabled:true}]}]};
test('worker saves valid rules, preserves prior state on DNR rejection, rolls back storage failure, and checks grants',async()=>{
 let r=await send({type:'save',settings});assert.equal(r.ok,true);assert.equal(dynamic.length,1);assert.deepEqual(stored,r.settings);assert.equal(stored.rules[0].headers[0].name,'user-agent');
 const prior=structuredClone(stored),priorDynamic=structuredClone(dynamic);
 rejectDNR=true;r=await send({type:'save',settings:{enabled:false,rules:[]}});assert.equal(r.ok,false);assert.deepEqual(stored,prior);assert.deepEqual(dynamic,priorDynamic);rejectDNR=false;
 rejectStorage=true;r=await send({type:'save',settings:{enabled:false,rules:[]}});assert.equal(r.ok,false);assert.deepEqual(dynamic,priorDynamic);rejectStorage=false;
 granted=false;r=await send({type:'save',settings});assert.equal(r.ok,false);assert.match(r.error,/Grant site access/);assert.deepEqual(dynamic,priorDynamic);granted=true;
 r=await send({type:'save',settings:{...settings,enabled:false}});assert.equal(r.ok,true);assert.deepEqual(dynamic,[]);
 r=await send({type:'get'});assert.equal(r.active,0);assert.equal(r.settings.enabled,false);
});
