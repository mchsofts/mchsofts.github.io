import {test} from 'node:test';
import assert from 'node:assert/strict';
import {labRule} from '../src/lab-rules.js';
test('lab headers use a session tab constraint and exact origin with higher priority',()=>{
 const r=labRule('https://example.com/path',[{name:'User-Agent',value:'Test/1',enabled:true},{name:'Referer',value:'https://test.example/',enabled:true}],42);
 assert.deepEqual(r.condition.tabIds,[42]);assert.equal(r.priority,10000);assert.equal(r.id,1000042);
 const re=new RegExp(r.condition.regexFilter);assert.ok(re.test('https://example.com/other'));assert.equal(re.test('https://other.example.com/'),false);assert.equal(r.action.requestHeaders.length,2);
});
test('blank overrides remove rule and unsafe values are rejected',()=>{
 assert.equal(labRule('https://example.com',[],1),null);
 assert.throws(()=>labRule('https://example.com',[],-1));
 assert.throws(()=>labRule('https://example.com',[{name:'Referer',value:'javascript:alert(1)',enabled:true}],1));
 assert.throws(()=>labRule('https://example.com',[{name:'User-Agent',value:'x\r\nInjected: 1',enabled:true}],1));
});
