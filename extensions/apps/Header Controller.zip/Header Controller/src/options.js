import {defaults,validate,originsFor} from './rules.js';
import {request,status,button} from './common.js';
const $=s=>document.querySelector(s);
let settings=defaults(),editing=null,busy=false;
function headerRow(h={name:'',value:'',enabled:true}) {
  const row=document.createElement('div');row.className='header-row';
  const enabled=document.createElement('input');enabled.type='checkbox';enabled.checked=h.enabled;enabled.setAttribute('aria-label','Enable header');
  const name=document.createElement('input');name.value=h.name;name.placeholder='Header name';name.setAttribute('aria-label','Header name');name.required=true;
  const value=document.createElement('input');value.value=h.value;value.placeholder='Header value';value.className='value';value.setAttribute('aria-label','Header value');value.required=true;
  const remove=button('×',()=>row.remove());remove.setAttribute('aria-label','Remove header');
  row.append(enabled,name,value,remove);$('#headers').append(row);
}
function clear(){editing=null;$('#editor').reset();$('#editor-title').textContent='Create rule';$('#headers').replaceChildren();['User-Agent','Referer','Origin'].forEach(name=>headerRow({name,value:'',enabled:false}));$('#headers').querySelectorAll('input:not([type=checkbox])').forEach(i=>i.required=false);}
async function persist(next){if(busy)throw Error('Please wait for the current update.');busy=true;try{const data=await request('save',next);settings=data.settings;await render();status('Saved. Reload affected sites to use the new rules.');}finally{busy=false;}}
async function action(fn){try{await fn();}catch(e){status(e.message,true);}}
async function render(){
  $('#master').checked=settings.enabled;$('#count').textContent=`${settings.rules.length} saved rules`;
  const list=$('#rules');list.replaceChildren();
  if(!settings.rules.length){const p=document.createElement('p');p.textContent='No rules yet. Add a scoped rule to get started.';list.append(p);}
  settings.rules.forEach((r,i)=>{
    const el=document.createElement('div');el.className='rule';const title=document.createElement('strong');title.textContent=r.name;
    const detail=document.createElement('small');detail.textContent=`${r.enabled?'Enabled':'Disabled'} · ${r.scope} · ${r.headers.filter(h=>h.enabled).length} active headers`;
    const actions=document.createElement('div');actions.className='actions';
    const toggle=button(r.enabled?'Disable':'Enable',()=>action(()=>persist({...settings,rules:settings.rules.map(x=>x.id===r.id?{...x,enabled:!x.enabled}:x)})));
    const edit=button('Edit',()=>{editing=r.id;$('#editor-title').textContent='Edit rule';$('#name').value=r.name;$('#scope').value=r.scope;$('#enabled').checked=r.enabled;$('#headers').replaceChildren();r.headers.forEach(headerRow);});
    const move=delta=>action(()=>{const rules=[...settings.rules];[rules[i],rules[i+delta]]=[rules[i+delta],rules[i]];return persist({...settings,rules});});
    const up=button('↑',()=>move(-1));up.disabled=i===0;up.setAttribute('aria-label','Increase priority');
    const down=button('↓',()=>move(1));down.disabled=i===settings.rules.length-1;down.setAttribute('aria-label','Decrease priority');
    const del=button('Delete',()=>action(async()=>{await persist({...settings,rules:settings.rules.filter(x=>x.id!==r.id)});if(editing===r.id)clear();}),'danger');
    actions.append(toggle,edit,up,down,del);el.append(title,detail,actions);list.append(el);
  });
  const grants=await chrome.permissions.getAll();$('#permissions').textContent='Granted sites: '+(grants.origins?.join(', ')||'none');
}
$('#editor').addEventListener('submit',async e=>{e.preventDefault();await action(async()=>{
  const headers=[...$('#headers').children].map(row=>{const inputs=row.querySelectorAll('input');return {enabled:inputs[0].checked,name:inputs[1].value,value:inputs[2].value};}).filter(h=>h.enabled || h.value.trim());
  const rule={id:editing||crypto.randomUUID(),name:$('#name').value,scope:$('#scope').value.trim(),enabled:$('#enabled').checked,headers};
  const next=validate({...settings,rules:editing?settings.rules.map(r=>r.id===editing?rule:r):[...settings.rules,rule]});
  const normalized=next.rules.find(r=>r.id===rule.id);
  // Request directly within the user gesture, before awaiting any other API.
  if(!await chrome.permissions.request({origins:originsFor(normalized.scope)}))throw Error('Site access declined. Rule was not saved.');
  await persist(next);clear();
});});
$('#master').addEventListener('change',()=>action(async()=>{try{await persist({...settings,enabled:$('#master').checked});}finally{$('#master').checked=settings.enabled;}}));
$('#add').onclick=()=>headerRow();$('#cancel').onclick=clear;$('#new').onclick=()=>{clear();$('#name').focus();};
$('#reset').onclick=()=>action(async()=>{if(confirm('Delete all rules and turn off modifications?')){await persist(defaults());clear();}});
$('#revoke').onclick=()=>action(async()=>{await persist({...settings,enabled:false});const grants=await chrome.permissions.getAll();if(grants.origins?.length)await chrome.permissions.remove({origins:grants.origins});await render();status('Site access revoked; modifications disabled.');});
chrome.permissions.onRemoved.addListener(()=>render().catch(e=>status(e.message,true)));
request('get').then(async data=>{settings=data.settings;await render();clear();}).catch(e=>status(e.message,true));
