import {httpURL, validate, compile} from './rules.js';
export function labRule(url, headers, tabId) {
  if (!Number.isInteger(tabId) || tabId < 0) throw Error('Open Iframe lab in its own browser tab.');
  const target=httpURL(url);
  const settings=validate({enabled:true,rules:[{id:'lab',name:'Iframe lab',enabled:true,scope:target.origin,headers}]});
  const [rule]=compile(settings);
  if (!rule) return null;
  return {...rule,id:1000000+tabId,priority:10000,condition:{...rule.condition,tabIds:[tabId]}};
}
