export const defaults = () => ({enabled: false, rules: []});
export function httpURL(value) {
  const u = new URL(value);
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) throw Error('Use an HTTP(S) URL without credentials.');
  return u;
}
export function scope(value) {
  if (value === '*') return '*';
  const u = httpURL(value);
  if (u.pathname !== '/' || u.search || u.hash) throw Error('Scope must be an origin, for example https://example.com (no path).');
  return u.origin;
}
export const originsFor = value => value === '*' ? ['http://*/*', 'https://*/*'] : [scope(value) + '/*'];
export function validate(input) {
  if (!input || typeof input.enabled !== 'boolean' || !Array.isArray(input.rules) || input.rules.length > 500) throw Error('Invalid settings (maximum 500 rules).');
  const ids = new Set();
  const rules = input.rules.map(r => {
    if (typeof r.id !== 'string' || !r.id || ids.has(r.id)) throw Error('Invalid or duplicate rule ID.');
    ids.add(r.id);
    if (typeof r.name !== 'string' || !r.name.trim() || r.name.length > 100 || typeof r.enabled !== 'boolean') throw Error('Enter a rule name (up to 100 characters).');
    if (!Array.isArray(r.headers) || r.headers.length > 30) throw Error('Maximum 30 headers per rule.');
    const names = new Set();
    const headers = r.headers.map(h => {
      const name = String(h.name).trim().toLowerCase();
      if (!/^[!#$%&'*+.^_`|~0-9a-z-]+$/.test(name)) throw Error('Invalid header name.');
      if (/^(sec-|proxy-)/.test(name) || ['host','connection','content-length','transfer-encoding','upgrade','cookie','authorization'].includes(name)) throw Error(name + ' is browser-managed or intentionally excluded.');
      if (names.has(name)) throw Error('Duplicate header in a rule.');
      names.add(name);
      if (typeof h.value !== 'string' || !h.value.trim() || h.value.length > 4096 || /[^\x20-\x7e]/.test(h.value)) throw Error('Header values must be nonempty printable ASCII, at most 4096 characters; no newlines.');
      if (name === 'referer') { const u = httpURL(h.value); if (u.hash) throw Error('Referer cannot contain a fragment.'); }
      if (name === 'origin' && h.value !== 'null' && httpURL(h.value).origin !== h.value) throw Error('Origin must be an exact origin or null.');
      if (typeof h.enabled !== 'boolean') throw Error('Invalid header toggle.');
      return {name, value: h.value, enabled: h.enabled};
    });
    return {id:r.id, name:r.name.trim(), enabled:r.enabled, scope:scope(r.scope), headers};
  });
  return {enabled:input.enabled, rules};
}
export function compile(settings) {
  const s = validate(settings);
  if (!s.enabled) return [];
  return s.rules.flatMap((r, index) => {
    const requestHeaders = r.headers.filter(h => h.enabled).map(h => ({header:h.name, operation:'set', value:h.value}));
    if (!r.enabled || !requestHeaders.length) return [];
    const regexFilter = r.scope === '*' ? '^https?://' : '^' + r.scope.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/';
    return [{id:index+1, priority:s.rules.length-index, action:{type:'modifyHeaders', requestHeaders}, condition:{regexFilter, isUrlFilterCaseSensitive:false, resourceTypes:['main_frame','sub_frame','stylesheet','script','image','font','object','xmlhttprequest','ping','media','other']}}];
  });
}
