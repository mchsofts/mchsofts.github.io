import {request,status,linkPages} from './common.js';
linkPages();
let settings;
const master=document.querySelector('#master');
async function refresh(){const data=await request('get');settings=data.settings;master.checked=settings.enabled;document.querySelector('#summary').textContent=`${settings.rules.length} saved rules · ${data.active} installed rules`;}
master.addEventListener('change',async()=>{master.disabled=true;try{await request('save',{...settings,enabled:master.checked});await refresh();status('Updated. Reload affected sites.');}catch(e){status(e.message,true);master.checked=settings.enabled;}finally{master.disabled=false;}});
refresh().catch(e=>status(e.message,true));
