import {httpURL,originsFor} from './rules.js';
import {labRule} from './lab-rules.js';
import {status} from './common.js';
const $=s=>document.querySelector(s);
let requested='',timer,frame,busy=false;
function selectedHeaders(){return [['user-agent','#user-agent'],['referer','#referer']].flatMap(([name,selector])=>{const value=$(selector).value;return value.trim()?[{name,value,enabled:true}]:[];});}
async function apply(url,headers){
  const tab=await chrome.tabs.getCurrent();
  const result=await chrome.runtime.sendMessage({type:'lab',url,headers,tabId:tab?.id});
  if(!result?.ok)throw Error(result?.error||'Could not install lab headers.');
}
function openFrame(url){
  requested=url;clearTimeout(timer);
  const current=document.createElement('iframe');frame=current;current.title='Website under test';
  const sandboxed=$('#sandbox').checked;
  if(sandboxed)current.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms');
  current.referrerPolicy='strict-origin-when-cross-origin';
  current.addEventListener('load',()=>{if(frame!==current)return;clearTimeout(timer);status('Frame load event received. Rendering is unverified; inspect DevTools if the site refuses access.');});
  current.addEventListener('error',()=>{if(frame!==current)return;clearTimeout(timer);status('Frame navigation reported an error. Inspect DevTools for the cause.',true);});
  current.src=url;$('#shell').replaceChildren(current);$('#current').textContent='Requested URL: '+url+' · Sandbox: '+(sandboxed?'on':'off');
  $('#reload').disabled=false;$('#direct').disabled=false;
  status('Lab headers applied. Navigation requested…');
  timer=setTimeout(()=>status('No conclusive frame event after 12 seconds. Check DevTools.',true),12000);
}
async function navigate(reload=false){
  if(busy)return;
  busy=true;
  try{
    const url=httpURL(reload?requested:$('#url').value.trim()).href;
    const headers=selectedHeaders();labRule(url,headers,0);
    // Optional permission request stays in the click/submit user gesture.
    if(headers.length && !await chrome.permissions.request({origins:originsFor(new URL(url).origin)}))throw Error('Site access declined. Navigation was not started.');
    await apply(url,headers);openFrame(url);
  }catch(e){status(e.message,true);}finally{busy=false;}
}
$('#open').onsubmit=e=>{e.preventDefault();navigate();};
$('#reload').onclick=()=>navigate(true);
$('#sandbox').onchange=()=>status('Sandbox setting changed. Click Reload frame or Apply headers & open iframe to apply it.');
$('#clear-headers').onclick=async()=>{if(busy)return;busy=true;try{await apply(requested||'https://example.com',[]);$('#user-agent').value='';$('#referer').value='';status('Lab overrides cleared. Saved rules may still apply. Reload to issue a new request.');}catch(e){status(e.message,true);}finally{busy=false;}};
$('#direct').onclick=()=>chrome.tabs.create({url:requested}).catch(e=>status(e.message,true));
function expand(){const expanded=document.body.classList.toggle('expanded');$('#expand').textContent=expanded?'Exit expanded view (Esc)':'Expand frame';}
$('#expand').onclick=expand;document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('expanded'))expand();});
$('#close-source').onclick=()=>{$('#source-panel').hidden=true;};
$('#source').onclick=async()=>{
  if(busy)return;busy=true;
  const controller=new AbortController();let timeout;
  try{
    const url=httpURL($('#url').value.trim());
    if(!await chrome.permissions.request({origins:originsFor(url.origin)}))throw Error('Site access declined. Source was not requested.');
    $('#source-panel').hidden=false;$('#source-code').textContent='Fetching source…';
    timeout=setTimeout(()=>controller.abort(),15000);
    const response=await fetch(url.href,{credentials:'omit',redirect:'error',cache:'no-store',signal:controller.signal});
    if(!response.ok)throw Error('Source request returned HTTP '+response.status);
    const reader=response.body.getReader(),decoder=new TextDecoder();let size=0,text='';
    while(true){const chunk=await reader.read();if(chunk.done)break;size+=chunk.value.byteLength;if(size>2*1024*1024){await reader.cancel();throw Error('Source exceeds the 2 MB display limit. Use DevTools Network → Response.');}text+=decoder.decode(chunk.value,{stream:true});}
    text+=decoder.decode();$('#source-code').textContent=text||'(Empty response)';status('Source fetched separately. This is not the live iframe document.');
  }catch(e){$('#source-code').textContent='Source unavailable. Use DevTools Network → document request → Response for the actual iframe response.';status(e.name==='AbortError'?'Source request timed out.':e.message+' Redirects, permissions or network policy may prevent source retrieval.',true);}
  finally{clearTimeout(timeout);busy=false;}
};
window.addEventListener('beforeunload',()=>clearTimeout(timer));
