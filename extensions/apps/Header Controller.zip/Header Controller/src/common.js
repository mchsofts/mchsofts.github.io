export async function request(type, settings) {
  const result = await chrome.runtime.sendMessage({type,settings});
  if (!result?.ok) throw Error(result?.error || 'Background service unavailable. Reopen this page.');
  return result;
}
export function status(message, error=false) { const el=document.querySelector('#status'); el.textContent=message; el.className=error?'status error':'status'; }
export function button(label, fn, className='') { const b=document.createElement('button'); b.type='button'; b.textContent=label; b.className=className; b.addEventListener('click',fn); return b; }
export function linkPages() { document.querySelectorAll('[data-page]').forEach(el=>el.addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL(el.dataset.page)}))); }
