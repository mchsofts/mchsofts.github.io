import {defaults, validate, compile, originsFor} from './rules.js';
import {labRule} from './lab-rules.js';
let queue = Promise.resolve();
async function read() { return (await chrome.storage.local.get('settings')).settings ?? defaults(); }
async function replace(settings) {
  const old = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:old.map(r=>r.id), addRules:compile(settings)});
}
async function save(input) {
  const settings = validate(input);
  for (const r of settings.rules.filter(r=>settings.enabled && r.enabled && r.headers.some(h=>h.enabled))) {
    if (!await chrome.permissions.contains({origins:originsFor(r.scope)})) throw Error('Grant site access for enabled rules before saving.');
  }
  const previous = await read();
  await replace(settings); // Chrome validates the whole replacement atomically.
  try { await chrome.storage.local.set({settings}); }
  catch (e) { await replace(previous); throw e; }
  await chrome.action.setBadgeText({text:settings.enabled?'ON':''});
  await chrome.action.setBadgeBackgroundColor({color:'#087f72'});
  return settings;
}
function enqueue(fn) { const result = queue.then(fn); queue = result.catch(()=>{}); return result; }
chrome.runtime.onMessage.addListener((m,sender,reply)=>{
  if (sender.id !== chrome.runtime.id) return;
  if(m?.type === 'lab') {
    enqueue(async()=>{
      if(sender.url !== chrome.runtime.getURL('iframe.html')) throw Error('Iframe lab requests only.');
      const tab=await chrome.tabs.get(m.tabId);
      if(tab.url !== chrome.runtime.getURL('iframe.html')) throw Error('Invalid lab tab.');
      const rule=labRule(m.url,m.headers,m.tabId);
      if(rule && !await chrome.permissions.contains({origins:originsFor(new URL(m.url).origin)})) throw Error('Grant access to this site first.');
      await chrome.declarativeNetRequest.updateSessionRules({removeRuleIds:[1000000+m.tabId],addRules:rule?[rule]:[]});
      return {ok:true};
    }).then(reply,e=>reply({ok:false,error:e.message}));
    return true;
  }
  if (!['get','save'].includes(m?.type)) return;
  enqueue(async()=> m.type === 'get' ? {settings:await read(), active:(await chrome.declarativeNetRequest.getDynamicRules()).length} : {settings:await save(m.settings)})
    .then(data=>reply({ok:true,...data}),e=>reply({ok:false,error:e.message}));
  return true;
});
const sync = () => enqueue(async()=>{const s=await read(); await replace(s); await chrome.action.setBadgeText({text:s.enabled?'ON':''});}).catch(console.error);
chrome.runtime.onInstalled.addListener(sync);
chrome.runtime.onStartup.addListener(sync);
chrome.tabs.onRemoved.addListener(tabId=>{
  enqueue(()=>chrome.declarativeNetRequest.updateSessionRules({removeRuleIds:[1000000+tabId]})).catch(console.error);
});
