# Header Controller

A dependency-free Chrome Manifest V3 extension for scoped HTTP request header changes and a real iframe workspace. UI language: English. No build step, external assets, content scripts, telemetry or remote JavaScript.

## Install

1. Use Chrome 121 or later. Download/copy this entire folder.
2. Visit `chrome://extensions`, enable **Developer mode**, choose **Load unpacked**, and select the folder containing `manifest.json`.
3. Pin Header Controller. Open **Manage rules** from the popup.
4. Add a rule with an exact origin, for example `http://127.0.0.1:8787`. Enable a header switch and supply its value. Click **Save & grant access**, accept Chrome's host permission prompt, then enable the master switch.
5. Reload the destination. Confirm headers in DevTools Network and, preferably, on a server you control.

No `npm install` is necessary. `npm test` runs unit tests with Node 18+. If npm is unavailable, use `node --test tests/rules.test.js tests/background.test.js`. `npm run fixture` (or `node tests/server.js`) starts the local development server on `127.0.0.1:8787`; stop with Ctrl+C. Node is needed only for tests and fixtures, not to run the extension.

## Files

- `manifest.json`: MV3 configuration and restrictive script CSP.
- `src/background.js`: serialized settings writes, atomic DNR replacement, startup reconciliation and badge.
- `src/rules.js`: shared input validation and deterministic DNR compiler.
- `popup.html`, `options.html`, `iframe.html`, `help.html`: popup, rule editor, frame workspace and diagnostics.
- `src/common.js`, `src/popup.js`, `src/options.js`, `src/iframe.js`: local UI modules.
- `style.css`, `icons/icon128.png`: responsive visual system and valid placeholder icon.
- `tests/`: compiler tests, mocked worker tests and local HTTP fixtures.

## Rule behavior

Defaults: master switch off, no rules. Multiple rules may target the same origin. Move rules up/down to set explicit priority: the top matching enabled rule wins for a conflicting header; distinct headers combine. Each header and each rule has its own switch. Header operations use DNR `set`; no response headers are changed.

Scopes are exact origins (scheme + hostname + port). Paths, subdomains and alternate schemes are not included automatically. `*` means all HTTP(S) destinations, only after explicit broad permission approval. Rules affect browser-wide matching requests, not just the iframe tab. Destination and sometimes initiator permissions are required by Chrome. To grant an initiator without modifying it, save a disabled rule for its origin. Nonmatching destinations are untouched. WebSockets, internal Chrome pages and non-HTTP schemes are outside this tool's scope.

The implementation caps input at 500 rules, 30 headers per rule and 4096 printable ASCII characters per value. DNR can impose additional limits; rejection is surfaced and the prior DNR rules remain installed. Settings are saved only after Chrome accepts the rules. If local storage fails, the worker attempts to restore the previous DNR set. Unexpected browser/process termination between the two APIs is not a multi-API transaction; startup reinstalls the last saved settings. Concurrent writes are serialized; multiple open editors should be refreshed to avoid stale edits.

## Permissions and privacy

Mandatory: `storage` and `declarativeNetRequestWithHostAccess`. HTTP(S) host patterns are **optional**, requested on rule save only. There is no mandatory all-sites access and no `tabs`, `webRequest`, `webNavigation`, debugger or scripting permission. `chrome.tabs.create` does not require the `tabs` permission. Chrome may describe a host permission more broadly than the rule itself; DNR conditions still use exact origin matching. Chrome can withhold or revoke access; the master indicator shows the configured state, not proof of effective network changes.

Settings use `chrome.storage.local` (not sync). No request logs are collected or transmitted. Do not store credentials in header values: storage is not a secret vault. Reset clears all rules and turns modifications off. **Revoke all site access** separately removes optional grants and disables modifications. Extension uninstall removes extension data. Iframe navigation contacts the destination like normal browsing.

## Technical limits

- A header change does not create an iframe. Only Iframe lab creates a real `<iframe>`.
- User-Agent HTTP changes do not emulate a browser or update JavaScript APIs / Client Hints.
- Origin and Referer values are best effort under Chrome constraints; verify what was sent. A successful DNR update is not proof of the final wire headers. Origin changes do not change the document's security origin, CORS authorization, or credentials.
- The tool excludes Host, transport framing headers, Cookie, Authorization, Sec-* and Proxy-* as a conservative product policy. This is not a universal list of DNR-forbidden headers. Other custom headers still depend on Chrome acceptance.
- X-Frame-Options and CSP frame-ancestors can refuse the lab's extension origin. Response protections are preserved. Configure an authorized test server to allow embedding rather than stripping policies.
- The iframe `load` event can fire for blocked navigations. Cross-origin DOM, final URL and policy failure reasons cannot reliably be read by the parent. The lab reports events and uncertainty, not false success. DevTools is the authoritative diagnostic path. No background browsing observation permission is requested just to infer errors.
- By default the sandbox allows scripts, forms and original origins but restricts top navigation/popups. The lab checkbox can disable this iframe sandbox explicitly before opening or reloading. Some flows intentionally need a normal tab. Expand fills the extension page viewport; it is not an OS fullscreen request. Reload restarts the last requested URL (cross-origin final URL is unreadable).
- CSP frame-src on a parent, frame-ancestors on a child, CORS, SameSite/third-party cookies, network failures and site checks are separate causes. See Help for steps to distinguish them. No access-control bypass is provided.

## Manual acceptance checklist

1. **Install:** load unpacked and verify no manifest/service worker errors. Open popup, options, iframe and help; resize the options window.
2. **Toggles:** create two rules for the fixture origin with User-Agent `HeaderController-Test/1`, Referer `https://example.com/test`, and a custom `X-Lab` value. Test master, rule and header switches independently. Reload `/echo` after every change.
3. **Wire headers:** with the fixture server running, open `http://127.0.0.1:8787/echo` directly and embedded. Check the server echo and Network → Request Headers. Try Origin `https://example.com` as best effort; document observed Chrome behavior, not an assumption.
4. **Scope isolation:** visit `http://localhost:8787/echo` (same server, distinct host) and confirm no modifications. The fixture listens on IPv4; use `http://127.0.0.1:8787` for the matching test. Also check a different port or external origin you control. Granting host access alone must not modify requests without a matching enabled rule.
5. **Priority / CRUD:** create conflicting values in two rules, reorder them and verify the top rule wins. Edit, disable and delete. Distinct headers should combine. Empty disabled preset rows are omitted on save; add them again if needed.
6. **Persistence:** quit and restart Chrome. Confirm settings, rule order, badge and `/echo` behavior persist. Turn master off and verify default headers return. Test reset.
7. **Iframe success:** open `http://127.0.0.1:8787/` in Iframe lab. Visually verify the fixture text. Test reload, expand/exit and direct tab. UI must still call rendering unverified rather than asserting success from load alone.
8. **Embedding failure:** open `/deny` and `/ancestors`; inspect Console for X-Frame-Options and frame-ancestors messages respectively. Open `/frame-src`: the outer fixture renders but its nested iframe is blocked by frame-src. Confirm no protections were removed.
9. **Invalid input:** try `javascript:` URL, credentials, scope with a path, duplicate headers, CR/LF injection, invalid Origin, Host and Sec-Fetch-Dest. Save must fail with a useful message and prior rules must remain. If Chrome rejects another custom header, its error must be reported with no settings replacement.
10. **Permissions:** decline a grant; rule must not be saved. Revoke grants in Chrome or the settings page; verify affected requests are no longer changed. Regrant from Save. Test a controlled cross-origin fetch with destination-only and initiator access.
11. **Other failures:** compare a direct versus framed login on your own test app. Use DevTools Issues/Cookies for cookie failures and Console for CORS. Do not label these as embedding policy failures without evidence.
12. **Recovery:** after malformed input or rejected Chrome rules, browse unrelated sites and confirm no changes or breakage. Restore defaults and verify no dynamic rules remain through the worker console: `chrome.declarativeNetRequest.getDynamicRules().then(console.log)`.

## Localization and maintenance

HTML uses `lang="en"`, local modules, semantic labels and live status regions. UI text is kept in presentation files rather than the compiler. A future Arabic locale can move text into `_locales/en/messages.json` and `_locales/ar/messages.json`, add `default_locale`, replace labels with `chrome.i18n.getMessage` and switch `lang`/`dir` together. RTL and translation are not currently implemented.

Official references: [DNR](https://developer.chrome.com/docs/extensions/reference/api/declarativeNetRequest), [permissions](https://developer.chrome.com/docs/extensions/develop/concepts/declare-permissions), [storage](https://developer.chrome.com/docs/extensions/reference/api/storage).

## Iframe lab quick headers and source

The lab now includes optional User-Agent and Referer inputs. Click **Apply headers & open iframe** to validate them, request destination access and install a tab-scoped DNR session rule before navigation. Empty fields keep browser/saved-rule behavior. Lab overrides have higher priority than saved rules and operate independently of the saved-rule master switch; use **Clear lab overrides** to remove them. These values are temporary, not saved profiles. Closing the tab or restarting Chrome removes session overrides. They target the entered URL's exact origin, including same-origin subresources, not third-party hosts or redirected origins. Header changes do not alter the actual parent origin or bypass domain protection.

**View page source** makes a separate permission-gated fetch of the entered URL with credentials omitted, a 15-second timeout, no redirect following and a 2 MB limit. The response is shown using textContent, never executed. It is not a live DOM inspector and may have different headers/content from the frame; it does not promise to reproduce navigation cookies or lab overrides. To inspect the actual frame response, use DevTools → Network → document request → Response. Failed fetches are reported without claiming that the source was retrieved.

Additional manual checks: open `/echo` with quick User-Agent and Referer values and inspect the echoed headers; compare a second lab tab and a normal tab; clear overrides and reload; try a Referer with an invalid scheme/newline; display `/` source and confirm HTML appears as text; compare `/deny` source with its refused frame; test source timeout, redirect and oversized-response errors. `node --test tests/rules.test.js tests/background.test.js tests/lab.test.js` runs all current automated tests.

## Optional iframe sandbox

Iframe lab includes **Enable iframe sandbox (recommended)**, enabled on each new lab page. Uncheck and click **Reload frame** or **Apply headers & open iframe** to create a new iframe without the sandbox attribute. Changing the checkbox alone does not change the running frame. The requested URL line shows the applied mode. Disabling the sandbox allows normal site behavior subject to Chrome rules, including potential popups/top navigation; it does not remove CSP, X-Frame-Options, same-origin policy or site access controls. No additional permissions are required.

Manual check: open the local fixture with the checkbox on; inspect the iframe for `sandbox="allow-scripts allow-same-origin allow-forms"`. Uncheck and reload; verify that the sandbox attribute is absent and the applied mode says off. Re-enable and reload to restore restrictions. A site-specific “Sandbox not allowed” message may disappear, but successful playback or access is not guaranteed.

## Credits

© 2026 mchsofts.com. Developed by [mchsofts.com](https://mchsofts.com). All rights reserved.
